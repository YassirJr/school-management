package com.schoolmanagement.server.enums;

public enum USER_ROLE_VALUES {
    STUDENT,
    TEACHER,
    CHEF
}
